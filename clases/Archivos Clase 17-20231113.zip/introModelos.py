# -*- coding: utf-8 -*-
"""
Materia: Laboratorio de datos - FCEyN - UBA
Clase  : Introduccion a Modelos
Autor  : Pablo Turjanski
Fecha  : 2023-05-15
"""


# Importamos bibliotecas
import pandas as pd
from inline_sql import sql, sql_val
import matplotlib.pyplot as plt
import seaborn as sns

def main():

   
    # Tablas originales
    carpeta       = "~/Downloads/"
    observaciones = pd.read_csv(carpeta+"datos_tiemposlibreta264n_50.csv", encoding="utf-8")
    
    #------------------------------------
    # Promedio
    #------------------------------------

    # Mostramos el promedio, usando funciones de Pandas
    print("Promedio Total         : ",observaciones['Tiempo'].mean())
    print("Promedio Mano Derecha  : ",observaciones[(observaciones['Mano']=='Derecha'  )]['Tiempo'].mean())
    print("Promedio Mano Izquierda: ",observaciones[(observaciones['Mano']=='Izquierda')]['Tiempo'].mean())

    # Mostramos el promedio, usando funciones de SQL
    print("Promedio Total         : ", (sql^ """SELECT AVG(Tiempo) FROM observaciones""").iloc[0][0])
    print("Promedio Mano Derecha  : ", (sql^ """SELECT AVG(Tiempo) FROM observaciones WHERE Mano='Derecha'""").iloc[0][0])
    print("Promedio Mano Izquierda: ", (sql^ """SELECT AVG(Tiempo) FROM observaciones WHERE Mano='Izquierda'""").iloc[0][0])
          
    #------------------------------------
    # Distribucion de los datos (plot)
    #------------------------------------

    fig, axes = plt.subplots(1, 3, figsize=(10, 3), sharey=True, dpi=100)
    sns.distplot(observaciones['Tiempo']                                      , color="orange"    , ax=axes[0], axlabel='Tiempo (Ambas) [s]')
    sns.distplot(observaciones[(observaciones['Mano']=='Derecha'  )]['Tiempo'], color="dodgerblue", ax=axes[1], axlabel='Tiempo (Derecha) [s]')
    sns.distplot(observaciones[(observaciones['Mano']=='Izquierda')]['Tiempo'], color="red"       , ax=axes[2], axlabel='Tiempo (Izquierda) [s]')


# =============================================================================
# EJECUCIÓN MAIN
# =============================================================================

if __name__ == "__main__":
    main()